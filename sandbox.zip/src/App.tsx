import { useState } from "react";
import "./App.css";

const phrases = [
  "Non.",
  "Pense à la romance de nos rêves, les romans sous une tente orange et violette...",
  "Pense à notre maisonette loin de la civilisation...",
  "Pitié Tom",
  "Je vais pleurer... Je serai une bonne femme promis!!",
  "On sera un couple weeb parfait",
  "Des soirées cyberharcélement...",
  "Jtm :((",
];

function App() {
  const [count, setCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonSize = count * 20 + 16;

  function handleNoClick() {
    setCount(count + 1);
  }

  function getNoButtonText() {
    return phrases[Math.min(count, phrases.length - 1)];
  }

  return (
    <div className="valentine-container">
      {yesPressed ? (
        <>
          <img
            alt="MaryNath"
            src="https://i.pinimg.com/564x/b4/d1/f8/b4d1f8b55cb00006e400ac74c2102021.jpg"
          />
          <div className="text">LETS GOOO JTM CHATON</div>
        </>
      ) : (
        <>
          <img
            alt="Proposal"
            src="https://i.pinimg.com/564x/b4/d1/f8/b4d1f8b55cb00006e400ac74c2102021.jpg"
          />
          <div>Veux-tu devenir mon homme?</div>
          <div>
            <button
              className="yesButton"
              style={{ fontSize: yesButtonSize }}
              onClick={() => setYesPressed(true)}
            >
              YES
            </button>
            <button onClick={handleNoClick} className="noButton">
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
